#include <stdio.h>

int main()
{
  
  int y;
  for(y=1;y<=20;y++)
  { 
    if(y>5)
    break;
    printf("%d\n",y);
  }
  return 0;
}