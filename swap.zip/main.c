/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() 
{
    double a,b,c;
    printf("value of a: ");
    scanf("%lf",&a);
    printf ("value of b:");
    scanf("%lf",&b);
    
    c=a;
    a=b;
    b=c;
    
    printf("\n after swapping, a = %.2lf\n",a);
    printf("\n after swapping, b = %.2lf\n",b);
 
   return 0;
}