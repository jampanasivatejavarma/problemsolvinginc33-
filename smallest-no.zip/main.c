#include<stdio.h>
 
int main()
{

   int n1,n2,n3;
   int smallest_no;
   int temp;
  

    printf("C Program to Find Smallest Number amound 3 Entered Number");

    printf("\n\n Enter Number 1: ");
    scanf("%i", &n1);
    
    printf("\n\n Enter Number 2: ");
    scanf("%i", &n2);
    
     printf("\n\n Enter Number 3: ");
    scanf("%i", &n3);
    

     
     
   
    if (n1 < n2)
    {
        if (n1 < n3) { 
            
            smallest_no = n1;
            
        }
        
        else {
            
             smallest_no = n3;
             
        }
    }

  else  if (n2 < n3) {
        
        smallest_no =  n2;
        
    }
    else 
     {
       smallest_no = n3;
     }
   
   printf("\n\n Smallest Among Numbers %i,%i and %i : %i",n1,n2,n3, smallest_no);
   return 0;
    
}
