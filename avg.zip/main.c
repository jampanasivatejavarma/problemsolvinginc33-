/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    float avg;
    printf("value of a");
    scanf("%d",&a);
    printf("value of b");
    scanf("%d",&b);
    printf("value of c");
    scanf("%d",&c);
    avg=(a+b+c)/3;
    printf("the average is: %.2f",avg);
    return 0;
}
