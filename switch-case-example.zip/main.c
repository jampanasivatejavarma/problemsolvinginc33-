/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int a, b, c, d, e, ch;
  float f, g;
  printf ("enter your choice:");
  scanf ("%d", &ch);

  a = 50;
  b = 20;
  c = a - b;
  d = a + b;
  e = a * b;
  f = a / b;
  g = a % b;
  switch(ch)
    {
      case 1:
      printf ("addition of two numbers %d", d);
      break;

      case 2:
      printf ("subtraction of two numbers %d", c);
      break;
      
      case 3:
      printf ("product of two numbers %d", e);
      break;
      
      case 4:
      printf ("division of two numbers %f", f);
      break;
      
      case 5:
      printf ("remainder of two numbers %f", g);
      break;
      
      default:printf("enter correct choice");
    }


return 0;


}
