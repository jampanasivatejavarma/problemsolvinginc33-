#include<stdio.h>



int main() 
{

int year;
  

    printf("C Program to Find Entered Year is a leap year or not.");

    printf("\n\n Enter Number : ");
    scanf("%i", &year);

     
     
    if ((year % 400 == 0) || ( ( year % 100 != 0) && (year % 4 == 0 ))) {
       
       printf("\n\n %i is a leap year!",year);
   }
   else {
       
       printf("\n\n %i is not a leap year!!",year);
   }
   

}