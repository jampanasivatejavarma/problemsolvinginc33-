#include <stdio.h>

int main()
{
  
  int y;
  for(y=1;y<=20;y++)
  { 
    if(y<5)
    goto l;
    printf("%d\n",y);
  }
  l:printf("%d",y);
  return 0;
}